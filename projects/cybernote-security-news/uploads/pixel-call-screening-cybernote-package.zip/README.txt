CyberNote Pixel通話スクリーニング掲載データ（2026-10-08）
・アイキャッチ：pixel-call-screening-eyecatch.png（1200x800）
・実例1：pixel-call-screening-case1.png（1月17日のNTTを名乗る不審電話）
・実例2：pixel-call-screening-case2.png（10月8日の通話途中切断）
・記事Markdown：pixel-call-screening-scam-call-2026.md

未掲載です。本文内のPIXEL_CASE1_IMAGE_URL、PIXEL_CASE2_IMAGE_URLはWordPressメディアへ画像をアップロードした後に置換してください。画像の取り違えを避けるため3枚を同梱しています。

メタディスクリプション：Pixelの通話スクリーニングで、2時間後に電話が使えなくなると告げる詐欺電話をAIが代わりに受けた実例を紹介。文字起こしで自動音声を見抜けた体験と、手口・設定方法・注意点を解説します。
